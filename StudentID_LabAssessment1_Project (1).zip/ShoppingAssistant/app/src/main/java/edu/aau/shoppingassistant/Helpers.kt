package edu.aau.shoppingassistant

import android.os.Bundle
import android.view.Gravity
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView

// Small helper functions that need Android classes (Bundle and TableLayout).

const val KEY_NAMES = "item_names"
const val KEY_PRICES = "item_prices"
const val KEY_QUANTITIES = "item_quantities"
const val KEY_DISCOUNT = "apply_discount"
const val KEY_TAX = "apply_tax"

fun packItems(items: List<BillItem>): Bundle {
    val bundle = Bundle()
    bundle.putStringArray(KEY_NAMES, items.map { it.name }.toTypedArray())
    bundle.putDoubleArray(KEY_PRICES, items.map { it.unitPrice }.toDoubleArray())
    bundle.putIntArray(KEY_QUANTITIES, items.map { it.quantity }.toIntArray())
    return bundle
}

fun packBill(items: List<BillItem>, applyDiscount: Boolean, applyTax: Boolean): Bundle {
    val bundle = packItems(items)
    bundle.putBoolean(KEY_DISCOUNT, applyDiscount)
    bundle.putBoolean(KEY_TAX, applyTax)
    return bundle
}

fun unpackItems(bundle: Bundle?): List<BillItem> {
    if (bundle == null) return emptyList()
    val names = bundle.getStringArray(KEY_NAMES) ?: return emptyList()
    val prices = bundle.getDoubleArray(KEY_PRICES) ?: return emptyList()
    val quantities = bundle.getIntArray(KEY_QUANTITIES) ?: return emptyList()

    val items = mutableListOf<BillItem>()
    for (i in names.indices) {
        if (i < prices.size && i < quantities.size) {
            items.add(BillItem(names[i], prices[i], quantities[i]))
        }
    }
    return items
}

fun addTableRow(table: TableLayout, cells: List<String>) {
    val context = table.context
    val padding = (8 * context.resources.displayMetrics.density).toInt()

    val row = TableRow(context)
    for ((index, cell) in cells.withIndex()) {
        val textView = TextView(context)
        textView.text = cell
        textView.textSize = 16f
        textView.setPadding(padding, padding, padding, padding)
        textView.gravity = if (index == 0) Gravity.START else Gravity.END
        row.addView(textView)
    }
    table.addView(row)
}
