package edu.aau.shoppingassistant

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.NavHostFragment

class ToolsFragment : Fragment(R.layout.fragment_tools) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        connectToolButtons(this, view)
    }
}

fun connectToolButtons(fragment: Fragment, view: View) {
    view.findViewById<Button>(R.id.btnCalculator)?.setOnClickListener {
        openTool(fragment, R.id.calculatorFragment)
    }
    view.findViewById<Button>(R.id.btnBill)?.setOnClickListener {
        openTool(fragment, R.id.billFragment)
    }
}

// Shows a tool in the NavHostFragment. The NavHostFragment is looked up through the Activity,
// because ToolsFragment is not inside it (on a wide screen it sits next to it).
fun openTool(fragment: Fragment, destinationId: Int) {
    val navHostFragment = fragment.requireActivity().supportFragmentManager
        .findFragmentById(R.id.navHostFragment) as NavHostFragment
    val navController = navHostFragment.navController
    val current = navController.currentDestination?.id

    if (current == destinationId) return

    // From Bill Summary the Bill Calculator button goes back to the existing bill
    if (current == R.id.billSummaryFragment && destinationId == R.id.billFragment) {
        navController.popBackStack()
        return
    }

    if (destinationId == R.id.calculatorFragment) {
        navController.navigate(R.id.action_global_calculator)
    } else {
        navController.navigate(R.id.action_global_bill)
    }
}
