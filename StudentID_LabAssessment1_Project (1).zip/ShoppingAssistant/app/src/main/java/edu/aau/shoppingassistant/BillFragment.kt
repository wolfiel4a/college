package edu.aau.shoppingassistant

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TableLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.textfield.TextInputLayout

class BillFragment : Fragment(R.layout.fragment_bill) {

    private val items = mutableListOf<BillItem>()

    private lateinit var nameLayout: TextInputLayout
    private lateinit var priceLayout: TextInputLayout
    private lateinit var quantityLayout: TextInputLayout
    private lateinit var nameInput: EditText
    private lateinit var priceInput: EditText
    private lateinit var quantityInput: EditText
    private lateinit var itemsTable: TableLayout
    private lateinit var discountBox: CheckBox
    private lateinit var taxBox: CheckBox
    private lateinit var messageText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // After a screen rotation the Fragment is created again, so take the saved items back
        if (savedInstanceState != null) {
            items.addAll(unpackItems(savedInstanceState))
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putAll(packItems(items))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        nameLayout = view.findViewById<TextInputLayout>(R.id.tilItemName)
        priceLayout = view.findViewById<TextInputLayout>(R.id.tilItemPrice)
        quantityLayout = view.findViewById<TextInputLayout>(R.id.tilItemQuantity)
        nameInput = view.findViewById<EditText>(R.id.etItemName)
        priceInput = view.findViewById<EditText>(R.id.etItemPrice)
        quantityInput = view.findViewById<EditText>(R.id.etItemQuantity)
        itemsTable = view.findViewById<TableLayout>(R.id.tableItems)
        discountBox = view.findViewById<CheckBox>(R.id.cbDiscount)
        taxBox = view.findViewById<CheckBox>(R.id.cbTax)
        messageText = view.findViewById<TextView>(R.id.tvBillMessage)

        // The screen is built again every time it is shown (also when coming back from Bill Summary),
        // so draw the table again from the list
        showItems()

        view.findViewById<Button>(R.id.btnAddItem).setOnClickListener { onAddItemClicked() }
        view.findViewById<Button>(R.id.btnCalculateBill).setOnClickListener { onCalculateClicked() }
        view.findViewById<Button>(R.id.btnBillClear).setOnClickListener { onClearClicked() }
        view.findViewById<Button>(R.id.btnBillHome).setOnClickListener {
            findNavController().popBackStack(R.id.homeFragment, false)
        }
    }

    // Draws one table row for every item. Row 0 is the header from the XML, so it is kept.
    private fun showItems() {
        if (itemsTable.childCount > 1) {
            itemsTable.removeViews(1, itemsTable.childCount - 1)
        }
        for (item in items) {
            addTableRow(
                itemsTable,
                listOf(item.name, formatAmount(item.unitPrice), item.quantity.toString())
            )
        }
    }

    private fun onAddItemClicked() {
        clearErrors()

        val name = nameInput.text.toString().trim()
        val price = parsePrice(priceInput.text.toString())
        val quantity = parseQuantity(quantityInput.text.toString())

        if (name.isEmpty()) nameLayout.error = getString(R.string.error_item_name)
        if (price == null) priceLayout.error = getString(R.string.error_item_price)
        if (quantity == null) quantityLayout.error = getString(R.string.error_item_quantity)

        if (name.isEmpty() || price == null || quantity == null) {
            messageText.text = getString(R.string.bill_message_not_added)
            return
        }

        items.add(BillItem(name, price, quantity))
        showItems()

        nameInput.setText("")
        priceInput.setText("")
        quantityInput.setText("")
        nameInput.requestFocus()

        messageText.text = getString(R.string.bill_message_added, items.size)
    }

    private fun onCalculateClicked() {
        clearErrors()

        val hasDraftItem = nameInput.text.toString().isNotBlank() ||
            priceInput.text.toString().isNotBlank() ||
            quantityInput.text.toString().isNotBlank()
        if (hasDraftItem) {
            messageText.text = getString(R.string.bill_message_draft)
            return
        }

        if (items.isEmpty()) {
            messageText.text = getString(R.string.bill_message_empty)
            return
        }

        val details = packBill(items, discountBox.isChecked, taxBox.isChecked)
        findNavController().navigate(R.id.action_bill_to_summary, details)
    }

    private fun onClearClicked() {
        items.clear()
        showItems()
        nameInput.setText("")
        priceInput.setText("")
        quantityInput.setText("")
        clearErrors()
        discountBox.isChecked = false
        taxBox.isChecked = false
        messageText.text = getString(R.string.bill_message_ready)
    }

    private fun clearErrors() {
        nameLayout.error = null
        priceLayout.error = null
        quantityLayout.error = null
    }
}
