package edu.aau.shoppingassistant

import java.util.Locale
import kotlin.math.abs

// Pure Kotlin logic (no Android classes), so it is easy to read and to test.

const val MAX_CALCULATOR_NUMBER = 1_000_000_000.0
const val MAX_CALCULATOR_RESULT = 1_000_000_000_000_000_000.0
const val MAX_UNIT_PRICE = 1_000_000.0
const val MAX_QUANTITY = 100_000
const val DISCOUNT_RATE = 0.10
const val TAX_RATE = 0.05

enum class Operation(val displayName: String) {
    ADD("summation"),
    SUBTRACT("subtraction"),
    MULTIPLY("multiplication"),
    DIVIDE("division")
}

data class BillItem(val name: String, val unitPrice: Double, val quantity: Int) {
    val lineTotal: Double
        get() = unitPrice * quantity
}

data class BillTotals(
    val subtotal: Double,
    val discount: Double,
    val tax: Double,
    val finalTotal: Double
)

fun parseNumber(text: String): Double? {
    val value = text.trim().toDoubleOrNull() ?: return null
    if (!value.isFinite() || abs(value) > MAX_CALCULATOR_NUMBER) return null
    return value
}

fun calculateResult(a: Double, b: Double, operation: Operation): Double {
    return when (operation) {
        Operation.ADD -> a + b
        Operation.SUBTRACT -> a - b
        Operation.MULTIPLY -> a * b
        Operation.DIVIDE -> a / b
    }
}

// True when the result cannot be shown clearly (infinite, or an unreadably huge number)
fun isResultTooLarge(result: Double): Boolean {
    return !result.isFinite() || abs(result) > MAX_CALCULATOR_RESULT
}

fun parsePrice(text: String): Double? {
    val value = text.trim().toDoubleOrNull() ?: return null
    if (!value.isFinite() || value <= 0.0 || value > MAX_UNIT_PRICE) return null
    return value
}

fun parseQuantity(text: String): Int? {
    val value = text.trim().toIntOrNull() ?: return null
    if (value < 1 || value > MAX_QUANTITY) return null
    return value
}

fun calculateBill(items: List<BillItem>, applyDiscount: Boolean, applyTax: Boolean): BillTotals {
    var subtotal = 0.0
    for (item in items) {
        subtotal += item.lineTotal
    }
    val discount = if (applyDiscount) subtotal * DISCOUNT_RATE else 0.0
    val amountAfterDiscount = subtotal - discount
    val tax = if (applyTax) amountAfterDiscount * TAX_RATE else 0.0
    return BillTotals(subtotal, discount, tax, amountAfterDiscount + tax)
}

// Two decimals with a dot, whatever the phone language is. Never shows -0.00.
fun formatAmount(value: Double): String {
    val text = String.format(Locale.US, "%.2f", value)
    return if (text == "-0.00") "0.00" else text
}
