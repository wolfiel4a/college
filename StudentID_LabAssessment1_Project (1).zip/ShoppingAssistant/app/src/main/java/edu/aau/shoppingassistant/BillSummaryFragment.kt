package edu.aau.shoppingassistant

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TableLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class BillSummaryFragment : Fragment(R.layout.fragment_bill_summary) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val items = unpackItems(arguments)
        val applyDiscount = arguments?.getBoolean(KEY_DISCOUNT, false) ?: false
        val applyTax = arguments?.getBoolean(KEY_TAX, false) ?: false
        val totals = calculateBill(items, applyDiscount, applyTax)

        val table = view.findViewById<TableLayout>(R.id.tableSummaryItems)
        for (item in items) {
            addTableRow(
                table,
                listOf(
                    item.name,
                    formatAmount(item.unitPrice),
                    item.quantity.toString(),
                    formatAmount(item.lineTotal)
                )
            )
        }

        view.findViewById<TextView>(R.id.tvSummaryInfo).text =
            getString(R.string.summary_info, items.size)
        view.findViewById<TextView>(R.id.tvSubtotal).text =
            getString(R.string.amount_aed, formatAmount(totals.subtotal))
        view.findViewById<TextView>(R.id.tvDiscount).text =
            getString(R.string.amount_aed, formatAmount(totals.discount))
        view.findViewById<TextView>(R.id.tvTax).text =
            getString(R.string.amount_aed, formatAmount(totals.tax))
        view.findViewById<TextView>(R.id.tvFinalTotal).text =
            getString(R.string.amount_aed, formatAmount(totals.finalTotal))

        view.findViewById<Button>(R.id.btnSummaryBack).setOnClickListener {
            findNavController().popBackStack()
        }
        view.findViewById<Button>(R.id.btnSummaryHome).setOnClickListener {
            findNavController().popBackStack(R.id.homeFragment, false)
        }
    }
}
