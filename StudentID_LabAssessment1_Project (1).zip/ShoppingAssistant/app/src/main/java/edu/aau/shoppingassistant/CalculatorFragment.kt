package edu.aau.shoppingassistant

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.textfield.TextInputLayout

class CalculatorFragment : Fragment(R.layout.fragment_calculator) {

    private lateinit var number1Layout: TextInputLayout
    private lateinit var number2Layout: TextInputLayout
    private lateinit var number1Input: EditText
    private lateinit var number2Input: EditText
    private lateinit var resultText: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        number1Layout = view.findViewById<TextInputLayout>(R.id.tilNumber1)
        number2Layout = view.findViewById<TextInputLayout>(R.id.tilNumber2)
        number1Input = view.findViewById<EditText>(R.id.etNumber1)
        number2Input = view.findViewById<EditText>(R.id.etNumber2)
        resultText = view.findViewById<TextView>(R.id.tvResult)

        view.findViewById<Button>(R.id.btnAdd).setOnClickListener { onOperationClicked(Operation.ADD) }
        view.findViewById<Button>(R.id.btnSubtract).setOnClickListener { onOperationClicked(Operation.SUBTRACT) }
        view.findViewById<Button>(R.id.btnMultiply).setOnClickListener { onOperationClicked(Operation.MULTIPLY) }
        view.findViewById<Button>(R.id.btnDivide).setOnClickListener { onOperationClicked(Operation.DIVIDE) }

        view.findViewById<Button>(R.id.btnCalcClear).setOnClickListener { onClearClicked() }
        view.findViewById<Button>(R.id.btnCalcHome).setOnClickListener {
            findNavController().popBackStack(R.id.homeFragment, false)
        }
    }

    private fun onOperationClicked(operation: Operation) {
        number1Layout.error = null
        number2Layout.error = null

        val a = parseNumber(number1Input.text.toString())
        val b = parseNumber(number2Input.text.toString())

        if (a == null) number1Layout.error = getString(R.string.error_number)
        if (b == null) number2Layout.error = getString(R.string.error_number)
        if (a == null || b == null) {
            resultText.text = getString(R.string.calc_no_result)
            return
        }

        if (operation == Operation.DIVIDE && b == 0.0) {
            number2Layout.error = getString(R.string.error_divide_by_zero)
            resultText.text = getString(R.string.calc_no_result)
            return
        }

        val result = calculateResult(a, b, operation)
        if (isResultTooLarge(result)) {
            resultText.text = getString(R.string.error_too_large)
            return
        }

        resultText.text = getString(R.string.calc_result, operation.displayName, formatAmount(result))
    }

    private fun onClearClicked() {
        number1Input.setText("")
        number2Input.setText("")
        number1Layout.error = null
        number2Layout.error = null
        resultText.text = getString(R.string.calc_default_result)
    }
}
