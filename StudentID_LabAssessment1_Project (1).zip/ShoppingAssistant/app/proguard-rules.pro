# Add project specific ProGuard rules here.
# This project does not use code shrinking (isMinifyEnabled = false), so nothing is needed.
